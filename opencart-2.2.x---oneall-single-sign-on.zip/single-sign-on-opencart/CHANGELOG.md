# Change Log

All notable changes to this project will be documented in this file. 
This project adheres to [Semantic Versioning](http://semver.org/).


## [Unreleased]

## [1.0.1] - 2018-07-12
### Fix
 - fix for social login plugin + cloud login

## [1.0.0] - 2018-06-26
### Added
- For version 2.0.0
